#include "openglwindow.h"
/*
OpenGLWindow::OpenGLWIndow(QOpenGLWindow *parent)
    : QOpenGLWindow(parent)
{

}
*/
OpenGLWindow::~OpenGLWindow()
{   
}
/*
void OpenGLWindow::initializeGL()
{
}

void OpenGLWindow::paintGL()
{
}

void OpenGLWindow::resizeGL()
{
}
*/
