/**
  THIS IS SAMPLE ONLY
  LET'S MAKE IT WORK ON YOUR OWN
**/

#include "CustomObject.h"
#include <QSGGeometryNode>
#include <QSGTextureMaterial>
#include <QSGMaterial>
#include <QQuickWindow>

CustomObject::CustomObject()
{

}

/**
 * @brief The CustomObject::TextureDeleter struct
 * This struct is use to delete Texture of item
 * This method prevent memory access error
 * also increase performance by threading delete
 */
struct CustomObject::TextureDeleter : public QRunnable
{
    TextureDeleter(QSGTexture* pTexture)
        : m_pTexture(pTexture)
    {
    }

    virtual void run()
    {
        if (m_pTexture)
        {
            delete m_pTexture;
        }
    }

    QSGTexture* m_pTexture;
};

/**
 * @brief override this method to custom rendering process
 * @param pOldNode: current drawing object of this Item (QQuickItem).
 * In initial, it is nullptr
 * @param pUpdatePaintNodeData: current data of pOldNode (Ex: rotation, translation, etc)
 * In initial, it is nullptr as well
 * @return Node that will be drawn on this custom object.
 *
 * Note: this method is usually called when something change on UI
 * which QML decide to redraw or we can call it manually by update() method on QML
 */
QSGNode *CustomObject::updatePaintNode(QSGNode *pOldNode, QQuickItem::UpdatePaintNodeData *pUpdatePaintNodeData)
{
    ///NOTE: we can replace with other pre-defined Node from Qt here
    QSGGeometryNode* pNode = nullptr;
    QSGGeometry* pGeometry = nullptr;
    QSGTextureMaterial* pMaterial = nullptr;

    if (!pOldNode)
    {
        ///Initial or item is null / empty
        pNode = new QSGGeometryNode();

        ///Create a item with 100 drawing points,
        ///Rectangle usually cost 4 points.
        ///More points help better quality for output item (anti-alias)
        ///NOTE: we can replace with other pre-defined Geometry from Qt here
        pGeometry = new QSGGeometry(QSGGeometry::defaultAttributes_TexturedPoint2D(), 100);

        ///OpenGL drawing mode
        ///See OpenGL definitions for detail
        pGeometry->setDrawingMode(GL_TRIANGLES);

        ///NOTE: we can replace with other pre-defined Material from Qt here
        pMaterial = new QSGTextureMaterial();

        ///See OpenGL definitions for these options
        pMaterial->setFlag(QSGMaterial::Blending);
        pMaterial->setFiltering(QSGTexture::Linear);
        pMaterial->setHorizontalWrapMode(QSGTexture::ClampToEdge);
        pMaterial->setVerticalWrapMode(QSGTexture::ClampToEdge);

        ///Assign geometry and material for node
        pNode->setGeometry(pGeometry);
        pNode->setMaterial(pMaterial);

        ///Flag that geometry and material will be released
        ///when node is released
        pNode->setFlag(QSGNode::OwnsGeometry);
        pNode->setFlag(QSGNode::OwnsMaterial);

    }
    else
    {
        /// Reuse the old node, but modify it to suit the new drawing
        /// or we can delete and create a new node, whatever
        pNode = dynamic_cast<QSGGeometryNode*>(pOldNode);
        pGeometry = pNode->geometry();

        ///Reallocate number of vertex points if size of item is changed
        ///This will help texture resizable whenever Item is resized on QML
        ///Or we can skip it and let QML resize them all :)
        ///But we really need it some cases
        pMaterial = dynamic_cast<QSGTextureMaterial*>(pNode->material());
        pGeometry->allocate(120);


    }

    ///Create a texture as an 100x100 pixel image.
    ///Each pixel will be 32 bit (ARGB - Alpha / Red / Green / Blue). Ex: 0xFFAABBCC
    ///QQuickWindow::TextureHasAlphaChannel tell Qt that this texture have transparency value
    ///Otherwise Qt will draw Alpha = FF (Not transparent)
    QSGTexture* m_pRasterTexture = window()->createTextureFromImage(*new QImage(100,100,QImage::Format_ARGB32), QQuickWindow::TextureHasAlphaChannel);

    ///OpenGL texture mode
    ///See OpenGL definitions for detail
    m_pRasterTexture->setFiltering(QSGTexture::Linear);
    m_pRasterTexture->setHorizontalWrapMode(QSGTexture::ClampToEdge);
    m_pRasterTexture->setVerticalWrapMode(QSGTexture::ClampToEdge);

    ///Assign texture for material
    pMaterial->setTexture(m_pRasterTexture);

    ///Tell Qt that geometry and material was updated
    ///and need to redraw
    pNode->markDirty(QSGNode::DirtyMaterial);
    pNode->markDirty(QSGNode::DirtyGeometry);

    ///Or we can create many child object and
    ///append to this object. Child object will overlap
    ///parent object & other child objects followed by index
    //pNode->appendChildNode(new QSGNode);

    return pNode;
}

/**
 * @brief CustomObject::releaseResources
 * Release resource if any in this method.
 * This method is execute whenever QML decided to release
 * an item.
 */
void CustomObject::releaseResources()
{
    ///We usually keep texture as a global member
    ///So we can only update it whenever we want
    ///It will make performance better than
    ///we have to create all contexts again
//    window()->scheduleRenderJob(new TextureDeleter(m_pRasterTexture), QQuickWindow::AfterSynchronizingStage);
}
