#include "appcommon.h"
#include "CustomObject.h"

///
/// \brief Register object for using it on QML
/// \param pUri
/// This pluggin will be registered to QML via "qmldir" file of each Qt module / project
///
void AppCommonPlugin::registerTypes(const char *pUri)
{
    qmlRegisterType<CustomObject>(pUri, 1, 0, "CustomObject");
}
