#ifndef CUSTOMOBJECT_H
#define CUSTOMOBJECT_H

#include <QQuickItem>
#include <QRunnable>
#include <QSGTexture>

class CustomObject : public QQuickItem
{
    Q_OBJECT
public:
    CustomObject();
protected:
    struct TextureDeleter;
    QSGNode* updatePaintNode(QSGNode* pOldNode, UpdatePaintNodeData* pUpdatePaintNodeData);
    void releaseResources();

};

#endif // CUSTOMOBJECT_H
