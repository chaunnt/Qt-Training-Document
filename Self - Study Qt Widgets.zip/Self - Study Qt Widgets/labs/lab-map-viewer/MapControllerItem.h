/*************************************************************************
 *
 * Copyright (c) 2016 Qt Group Plc.
 * All rights reserved.
 *
 * See the LICENSE.txt file shipped along with this file for the license.
 *
 *************************************************************************/

#ifndef MAPCONTROLLERITEM_H_
#define MAPCONTROLLERITEM_H_

class MapControllerItem /* : public ... */
{
public:
	MapControllerItem( /*...*/ );
	~MapControllerItem();
	
	/*...*/
};

#endif /*MAPCONTROLLERITEM_H_*/
