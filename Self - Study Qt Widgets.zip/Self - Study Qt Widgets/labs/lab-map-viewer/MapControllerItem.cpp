/*************************************************************************
 *
 * Copyright (c) 2016 The Qt Company
 * All rights reserved.
 *
 * See the LICENSE.txt file shipped along with this file for the license.
 *
 *************************************************************************/

#include "MapControllerItem.h"

MapControllerItem::MapControllerItem()
{
}

MapControllerItem::~MapControllerItem()
{
}
