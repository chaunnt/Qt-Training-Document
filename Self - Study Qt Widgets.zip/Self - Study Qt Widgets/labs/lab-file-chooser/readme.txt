Lab: File Chooser
=================

Create a reusable component, which allows the user to choose a file (or directory) from a file dialog. The file shall be displayed in a line edit.

The file chooser has 2 modes:
- File Mode
- Directory Mode

Make sure you have a nice designed API, which utilizes also Qt SIGNAL&SLOT mechanisms.
