Lab Order Form
==============

Please create a form to order a product. The order comprises of a name, price, quantity and a total.

* The price can be a QSpinBox
* The quantity and total fields can be QDoubleSpinbox
* The total field should be read-only

When the user changes the quantity or price the total price should be updated accordingly.

Please use Qt Creator and Qt Designer.

Note: As usual the dialog should also have a ok + cancel button which will close the dialog and a proper dialog title.
