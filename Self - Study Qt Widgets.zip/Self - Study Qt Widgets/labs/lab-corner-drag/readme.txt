GraphicsView Lab: CornerDrag

Already done for you in the handout, 4 corner buttons are added
to a main picture item.  Also, a picture item with a sample image
is already added to the handout.

In this lab, we will add the mouse handler events that will permit
the "corner drag buttons" to allow you to either resize or rotate 
the parent image.

Dragging on the corner button should perform an appropriate 
transformation on the image itself. You can choose whether you want
to implement just one operation (scale or rotate) or
more than one, selectable via modifier keys.

