/*************************************************************************
 *
 * Copyright (c) 2016 The Qt Company
 * All rights reserved.
 *
 * See the LICENSE.txt file shipped along with this file for the license.
 *
 *************************************************************************/

#include "slider.h"


Slider::Slider(Qt::Orientation orient, QWidget *parent)
    : QWidget(parent)
{}
