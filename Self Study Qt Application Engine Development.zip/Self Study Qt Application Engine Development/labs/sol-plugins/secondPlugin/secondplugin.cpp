#include "secondplugin.h"


SecondPlugin::SecondPlugin()
{
}

QString SecondPlugin::getTheString(void) const
{
        return QString("The second Plug-in");
}


