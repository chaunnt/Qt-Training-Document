/*************************************************************************
 *
 * Copyright (c) 2016 The Qt Company
 * All rights reserved.
 *
 * See the LICENSE.txt file shipped along with this file for the license.
 *
 *************************************************************************/

#include "firstplugin.h"

FirstPlugin::FirstPlugin()
{
}

QString FirstPlugin::getTheString(void) const
{
    return QString("The first Plug-in");
}





