Lab Keys XML
============

The KeyEngine is capable of storing key-value pairs. It has a limitation of not being able to store the data persistent.

Your task is it to provide an XML reading and writing backend. Some clever engineers have already started
with a KeysXmlWriter and KeysXmlReader class and provided a simple main method with test code.

Good Luck!
----------

The format the xml is specified looks like this.

=== Xml ===

<?xml version="1.0" encoding="UTF-8"?>
<keys version="1.0">
    <item key="Key-0">Value-0</item>
    <item key="Key-1">Value-1</item>
    <item key="Key-8">Value-8</item>
    <item key="Key-9">Value-9</item>
</keys>

==========

