Using the partial solutions as hints, create a user interface
similar to the one shown in the slides.

Use the background image supplied in the common images
directory for the background gradient.
